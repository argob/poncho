from string import Template
from colors import colors as _c

def createMarker(color, name):
    with open("marker_svg_template.txt", "r") as f:
        tpl = Template(f.read())
        sub = tpl.substitute({'color': color, 'name': name, 'id': name.replace('-', '_')})
        return sub
  
  
def createFile(name, svg):
    with open(f"./markers/marcador-{name}.svg", "w") as f:
        f.write(svg)
        

for entry in _c:
    for color in entry[0]:
        svg = createMarker(entry[1], color)
        createFile(color, svg)
